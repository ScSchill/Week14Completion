using System.Collections;
using UnityEngine;

public class HealthPowerup : MonoBehaviour
{
    public float lifetime = 4f;          // How long the heart stays on screen
    public AudioClip pickupClip;         // Sound to play on pickup
    public int lifeAmount = 1;           // Amount of lives restored
    public bool giveScoreIfFull = true;  // Bonus score if player already full health

    [Header("Visual Settings")]
    public float scaleSize = 0.5f;       // Smaller heart size

    void Start()
    {
        // Apply visual scale
        transform.localScale = new Vector3(scaleSize, scaleSize, scaleSize);

        // Destroy heart after lifetime
        Destroy(gameObject, lifetime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;

        Player player = other.GetComponent<Player>();
        if (player == null) return;

        // Give life if player not full
        if (player.lives < player.maxLives)
        {
            player.AddLife(lifeAmount);
        }
        else if (giveScoreIfFull)
        {
            // Bonus score if full health
            GameManager gm = FindObjectOfType<GameManager>();
            if (gm != null)
                gm.AddScore(1);
        }

        // Play pickup sound at player position
        if (pickupClip != null)
            AudioSource.PlayClipAtPoint(pickupClip, player.transform.position);

        // Destroy the heart
        Destroy(gameObject);
    }
}
