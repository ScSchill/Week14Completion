using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int points = 1; // Score given for this enemy
    private GameManager gameManager;
    private float speed = 3f;

    void Start()
    {
        gameManager = FindObjectOfType<GameManager>();
    }

    void Update()
    {
        // Move downward
        transform.Translate(Vector3.down * speed * Time.deltaTime);

        // Destroy if off-screen
        if (transform.position.y < -6.5f)
            Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Bullet collision
        if (collision.CompareTag("Bullet"))
        {
            if (gameManager != null)
                gameManager.AddScore(points);

            Destroy(collision.gameObject); // Destroy bullet
            Destroy(gameObject);           // Destroy enemy
        }

        // Player collision
        if (collision.CompareTag("Player"))
        {
            Player player = collision.GetComponent<Player>();
            if (player != null && gameManager != null)
            {
                gameManager.DamagePlayer(player, 1); // Reduce life by 1
            }

            Destroy(gameObject); // Enemy destroyed on collision
        }
    }
}
