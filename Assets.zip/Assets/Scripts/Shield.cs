using System.Collections;
using UnityEngine;

public class ShieldPowerup : MonoBehaviour
{
    public float lifetime = 5f;          // How long powerup stays on the ground
    public float shieldDuration = 6f;    // How long shield lasts on player
    public AudioClip pickupClip;         // Sound on pickup
    public AudioClip shieldEndClip;      // Optional: passed to player

    [Header("Visual Settings")]
    public float scaleSize = 1.0f;       // Visual size of shield

    void Start()
    {
        // Set visual scale
        transform.localScale = new Vector3(scaleSize, scaleSize, scaleSize);

        // Destroy powerup after lifetime
        Destroy(gameObject, lifetime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;

        Player player = other.GetComponent<Player>();
        if (player == null) return;

        // Play pickup sound at player position
        if (pickupClip != null)
        {
            AudioSource.PlayClipAtPoint(pickupClip, player.transform.position);
        }

        // Activate shield on player
        player.EnableShield(shieldDuration, shieldEndClip);

        // Destroy shield powerup so it cannot be picked again immediately
        Destroy(gameObject);
    }
}
