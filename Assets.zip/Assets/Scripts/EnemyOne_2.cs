using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy2 : MonoBehaviour
{
    private float speed;
    private Vector3 moveDirection;
    public int points = 1;
    private GameManager gameManager;
    public Transform player;

    void Start()
    {
        gameManager = FindObjectOfType<GameManager>();
        speed = Random.Range(2f, 8f);

        if (player != null)
        {
            Vector3 target = player.position;
            moveDirection = (target - transform.position).normalized;

            // Ensure minimum movement
            if (Mathf.Abs(moveDirection.x) < 0.3f)
                moveDirection.x = moveDirection.x < 0 ? -0.3f : 0.3f;
            if (Mathf.Abs(moveDirection.y) < 0.3f)
                moveDirection.y = moveDirection.y < 0 ? -0.3f : 0.3f;
        }
        else
        {
            moveDirection = new Vector3(0.5f, -1f, 0).normalized;
        }
    }

    void Update()
    {
        transform.Translate(moveDirection * speed * Time.deltaTime);

        if (transform.position.y < -6.5f)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Bullet collision
        if (collision.CompareTag("Bullet"))
        {
            if (gameManager != null)
                gameManager.AddScore(points);

            Destroy(collision.gameObject);
            Destroy(gameObject);
        }

        // Player collision
        if (collision.CompareTag("Player"))
        {
            Player playerScript = collision.GetComponent<Player>();
            if (playerScript != null && gameManager != null)
            {
                gameManager.DamagePlayer(playerScript, 1); // Player loses 1 life unless shielded
            }

            Destroy(gameObject); // Enemy destroyed on collision
        }
    }
}
