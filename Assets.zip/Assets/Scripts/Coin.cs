using System.Collections;
using UnityEngine;

public class Coin : MonoBehaviour
{
    public float lifetime = 3f; // Coin disappears after 3 seconds

    void Start()
    {
        // Destroy coin after a few seconds if not collected
        Destroy(gameObject, lifetime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            // Add score via GameManager
            GameManager gm = FindObjectOfType<GameManager>();
            if (gm != null)
            {
                gm.AddScore(1);
            }

            // Destroy coin after collection
            Destroy(gameObject);
        }
    }
}
