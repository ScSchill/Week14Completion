using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed = 8f;

    void Update()
    {
        // Move bullet upward
        transform.Translate(Vector3.up * speed * Time.deltaTime);

        // Destroy if off-screen
        if (transform.position.y > 6.5f)
        {
            Destroy(gameObject);
        }
    }

    // Collision detection
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Enemy"))
        {
            // Destroy enemy
            Destroy(collision.gameObject);

            // Destroy bullet
            Destroy(gameObject);

            // Add score
            GameManager gm = FindObjectOfType<GameManager>();
            if (gm != null)
            {
                gm.AddScore(1); // Increase by 1 for each enemy hit
            }
        }
    }
}
