using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    private float playerSpeed;
    private float horizontalInput;
    private float verticalInput;

    private float horizontalScreenLimit = 9.5f;
    private float verticalScreenLimit = 6.5f;

    public GameObject bulletPrefab;
    public GameObject bigBulletPrefab;

    // ================= LIVES SYSTEM =================
    public int lives = 3;
    public int maxLives = 3;

    private GameManager gameManager;

    // ================= SHIELD SYSTEM =================
    private bool isShielded = false;
    public GameObject shieldVisual;

    void Start()
    {
        playerSpeed = 6f;
        gameManager = FindObjectOfType<GameManager>();

        if (gameManager != null)
            gameManager.UpdateLivesUI(lives);
    }

    void Update()
    {
        HandleMovement();
        HandleShooting();
    }

    void HandleShooting()
    {
        if (Input.GetKeyDown(KeyCode.Space))
            Instantiate(bulletPrefab, transform.position + Vector3.up, Quaternion.identity);

        if (Input.GetKeyDown(KeyCode.E))
            Instantiate(bigBulletPrefab, transform.position + Vector3.up, Quaternion.identity);
    }

    void HandleMovement()
    {
        horizontalInput = Input.GetAxis("Horizontal");
        verticalInput = Input.GetAxis("Vertical");

        transform.Translate(new Vector3(horizontalInput, verticalInput, 0) * Time.deltaTime * playerSpeed);

        // Wrap horizontally
        if (transform.position.x > horizontalScreenLimit || transform.position.x <= -horizontalScreenLimit)
            transform.position = new Vector3(transform.position.x * -1, transform.position.y, 0);

        // Clamp vertical
        float clampedY = Mathf.Clamp(transform.position.y, -verticalScreenLimit, 0.5f);
        transform.position = new Vector3(transform.position.x, clampedY, 0);
    }

    // ================= COLLISION HANDLING =================
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Shield"))
        {
            gameManager.ActivateShield(this);
            Destroy(other.gameObject);
        }

        if (other.CompareTag("Health"))
        {
            gameManager.GrantHealth(this);
            // Heart is not destroyed to allow continuous spawning
        }

        if (other.CompareTag("Coin"))
        {
            gameManager.AddScore(1);
            Destroy(other.gameObject);
        }

        if (other.CompareTag("Enemy") || other.CompareTag("Enemy2") || other.CompareTag("Enemy3"))
        {
            if (!isShielded)
                TakeDamage(1); // Lose exactly 1 life per hit

            Destroy(other.gameObject); // Destroy enemy on collision
        }
    }

    // ================= LIVES METHODS =================
    public void AddLife(int amount)
    {
        lives = Mathf.Clamp(lives + amount, 0, maxLives);
        gameManager?.UpdateLivesUI(lives);
        Debug.Log("Player Lives: " + lives);
    }

    public void TakeDamage(int amount)
    {
        if (isShielded) return;

        lives = Mathf.Clamp(lives - amount, 0, maxLives);
        gameManager?.UpdateLivesUI(lives);
        Debug.Log("Player damaged! Lives: " + lives);

        if (lives <= 0)
        {
            Debug.Log("GAME OVER");
            // Add game over UI or scene transition here
        }
    }

    // ================= SHIELD METHODS =================
    public void EnableShield(float duration, AudioClip shieldEndClip = null)
    {
        StopAllCoroutines();
        StartCoroutine(ShieldRoutine(duration, shieldEndClip));
    }

    private IEnumerator ShieldRoutine(float duration, AudioClip shieldEndClip)
    {
        isShielded = true;
        if (shieldVisual != null)
            shieldVisual.SetActive(true);

        Debug.Log("Shield Activated!");
        yield return new WaitForSeconds(duration);

        isShielded = false;
        if (shieldVisual != null)
            shieldVisual.SetActive(false);

        Debug.Log("Shield Deactivated");

        if (shieldEndClip != null)
            AudioSource.PlayClipAtPoint(shieldEndClip, transform.position);
    }

    public bool IsShielded()
    {
        return isShielded;
    }
}
