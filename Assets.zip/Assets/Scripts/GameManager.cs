using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    [Header("Enemy Prefabs")]
    public GameObject enemyOnePrefab;
    public GameObject enemyTwoPrefab;
    public GameObject enemyThreePrefab;

    [Header("UI Elements")]
    public TMP_Text scoreText;
    public TMP_Text livesText;

    [Header("Coin Settings")]
    public GameObject coinPrefab;

    [Header("Powerups")]
    public GameObject shieldPowerupPrefab;
    public GameObject healthPowerupPrefab;

    [Header("Powerup Sounds")]
    public AudioClip shieldPickupSound;
    public AudioClip shieldEndSound;
    public AudioClip healthPickupSound;

    private int score = 0;

    private float horizontalScreenLimit = 9f;
    private float verticalScreenMin = -6.5f;
    private float verticalScreenMax = 0.5f;

    // Center-only spawn limits for powerups
    private float centerHorizontalLimit = 4f;
    private float centerVerticalMin = -3f;
    private float centerVerticalMax = -0.5f;

    void Start()
    {
        // Spawn enemies
        InvokeRepeating("CreateEnemyOne", 1f, 2f);
        InvokeRepeating("CreateEnemyTwo", 2f, 3f);
        InvokeRepeating("CreateEnemyThree", 3f, 4f);

        // Spawn coins
        InvokeRepeating("SpawnCoin", 1f, 2.5f);

        // Spawn powerups
        InvokeRepeating("SpawnShieldPowerup", 5f, 12f);
        InvokeRepeating("SpawnHealthPowerup", 8f, 8f); // shorter interval for continuous hearts

        UpdateScoreText();
    }

    #region Enemy Spawning
    void CreateEnemyOne()
    {
        Instantiate(enemyOnePrefab, new Vector3(Random.Range(-9f, 9f), 6.5f, 0), Quaternion.identity);
    }

    void CreateEnemyTwo()
    {
        Instantiate(enemyTwoPrefab, new Vector3(Random.Range(-9f, 9f), 6.5f, 0), Quaternion.identity);
    }

    void CreateEnemyThree()
    {
        Instantiate(enemyThreePrefab, new Vector3(Random.Range(-9f, 9f), 6.5f, 0), Quaternion.identity);
    }
    #endregion

    #region Coin Spawning
    void SpawnCoin()
    {
        if (coinPrefab != null)
        {
            Vector3 spawnPos = GetRandomPlayZonePosition();
            GameObject coin = Instantiate(coinPrefab, spawnPos, Quaternion.identity);
            coin.transform.localScale = Vector3.one * 0.7f;
            Destroy(coin, 4f);
        }
    }
    #endregion

    #region Powerup Spawning
    void SpawnShieldPowerup()
    {
        if (shieldPowerupPrefab != null)
        {
            Vector3 spawnPos = GetCentralPlayZonePosition();
            GameObject shield = Instantiate(shieldPowerupPrefab, spawnPos, Quaternion.identity);
            shield.transform.localScale = Vector3.one * 0.6f; // smaller size for better pickup
            Destroy(shield, 6f);
        }
    }

    void SpawnHealthPowerup()
    {
        if (healthPowerupPrefab != null)
        {
            Vector3 spawnPos = GetCentralPlayZonePosition();
            GameObject heart = Instantiate(healthPowerupPrefab, spawnPos, Quaternion.identity);
            heart.transform.localScale = Vector3.one * 0.5f;
            Destroy(heart, 6f);
        }
    }
    #endregion

    #region Position Helpers
    Vector3 GetRandomPlayZonePosition()
    {
        float x = Random.Range(-horizontalScreenLimit + 1f, horizontalScreenLimit - 1f);
        float y = Random.Range(verticalScreenMin + 1f, verticalScreenMax - 1f);
        return new Vector3(x, y, -1);
    }

    Vector3 GetCentralPlayZonePosition()
    {
        float x = Random.Range(-centerHorizontalLimit, centerHorizontalLimit);
        float y = Random.Range(centerVerticalMin, centerVerticalMax);
        return new Vector3(x, y, -1);
    }
    #endregion

    #region Score Management
    public void AddScore(int amount)
    {
        score += amount;
        UpdateScoreText();
    }

    private void UpdateScoreText()
    {
        if (scoreText != null)
            scoreText.text = "Score: " + score;
        else
            Debug.LogWarning("⚠️ ScoreText reference not set in GameManager!");
    }
    #endregion

    #region Powerup Effects
    public void ActivateShield(Player player)
    {
        player.EnableShield(6f, shieldEndSound);
        if (shieldPickupSound != null)
            AudioSource.PlayClipAtPoint(shieldPickupSound, player.transform.position);
    }

    public void GrantHealth(Player player)
    {
        if (player.lives < player.maxLives)
        {
            player.AddLife(1);
            if (healthPickupSound != null)
                AudioSource.PlayClipAtPoint(healthPickupSound, player.transform.position);
        }
        else
        {
            AddScore(1); // full health bonus
            if (healthPickupSound != null)
                AudioSource.PlayClipAtPoint(healthPickupSound, player.transform.position);
        }
    }
    #endregion

    #region UI
    public void UpdateLivesUI(int lives)
    {
        if (livesText != null)
            livesText.text = "Lives: " + lives + " / 3";
    }
    #endregion

    #region Enemy Collision Damage
    public void DamagePlayer(Player player, int damage = 1)
    {
        if (!player.IsShielded())
        {
            player.TakeDamage(damage);
            UpdateLivesUI(player.lives);
        }
    }
    #endregion
}
