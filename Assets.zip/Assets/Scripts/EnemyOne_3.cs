using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyThree : MonoBehaviour
{
    private float speed;
    private float circleRadius;
    private float circleFrequency;
    private Vector3 startPosition;
    private Transform Player;
    private float timeOffset;
    public int points = 2; // Enemy gives more points
    private GameManager gameManager;

    void Start()
    {
        gameManager = FindObjectOfType<GameManager>();

        speed = Random.Range(1.5f, 5f);
        circleRadius = Random.Range(0.5f, 3f);
        circleFrequency = Random.Range(1f, 5f);
        startPosition = transform.position;

        Player = GameObject.FindWithTag("Player")?.transform;

        timeOffset = Random.Range(0f, 2 * Mathf.PI);
    }

    void Update()
    {
        Vector3 direction = Vector3.down;

        if (Player != null)
        {
            float horizontalDir = Mathf.Sign(Player.position.x - transform.position.x);
            direction.x = horizontalDir * 0.3f;
        }

        float xOffset = Mathf.Cos(Time.time * circleFrequency + timeOffset) * circleRadius;
        float yOffset = Mathf.Sin(Time.time * circleFrequency + timeOffset) * circleRadius;
        Vector3 circularMovement = new Vector3(xOffset, yOffset, 0);

        transform.Translate((direction + circularMovement) * speed * Time.deltaTime);

        if (transform.position.y < -6.5f)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Bullet collision
        if (collision.CompareTag("Bullet"))
        {
            if (gameManager != null)
                gameManager.AddScore(points);

            Destroy(collision.gameObject);
            Destroy(gameObject);
        }

        // Player collision
        if (collision.CompareTag("Player"))
        {
            Player playerScript = collision.GetComponent<Player>();
            if (playerScript != null && gameManager != null)
            {
                gameManager.DamagePlayer(playerScript, 1); // Player loses 1 life unless shielded
            }

            Destroy(gameObject); // Enemy destroyed on hitting player
        }
    }
}
